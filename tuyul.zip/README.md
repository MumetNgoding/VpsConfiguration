# tuyul.php
Auto claim
